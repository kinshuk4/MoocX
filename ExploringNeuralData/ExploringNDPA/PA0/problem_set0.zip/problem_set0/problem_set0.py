### Save this file back as problem_set0.py when you are done

'''
Part 1: Write a function that returns the string "hello, world"
'''

def hello_world():
	# Your code here ---


	# ------------------



   
